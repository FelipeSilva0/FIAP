package br.com.fiap;


import br.com.fiap.view.Janela;

public class App {

	public static void main(String[] args) {
		new Janela().init();
	}
}
